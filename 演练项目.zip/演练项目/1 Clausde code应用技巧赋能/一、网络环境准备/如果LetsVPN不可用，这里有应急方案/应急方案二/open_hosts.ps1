# Check if running as administrator
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")

if (-not $isAdmin) {
    # Rerun as administrator if not already
    Start-Process powershell -Verb RunAs -ArgumentList "-File", "$PSCommandPath"
    exit
}

# Load required assemblies
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Define file paths using relative path
$githubHostsPath = Join-Path -Path $PSScriptRoot -ChildPath "github_hosts.txt"
$hostsPath = "C:\Windows\System32\drivers\etc\hosts"

# Create form
$form = New-Object System.Windows.Forms.Form
$form.Text = "GitHub Hosts Tool"
$form.Size = New-Object System.Drawing.Size(400, 180)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false

# Create label
$label = New-Object System.Windows.Forms.Label
$label.Location = New-Object System.Drawing.Point(20, 20)
$label.Size = New-Object System.Drawing.Size(360, 60)
$label.Text = "Please paste GitHub IPs into hosts file."
$label.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$form.Controls.Add($label)

# Create button
$button = New-Object System.Windows.Forms.Button
$button.Location = New-Object System.Drawing.Point(120, 100)
$button.Size = New-Object System.Drawing.Size(160, 30)
$button.Text = "Copy and Open"

# Button click event
$button.Add_Click({
    # Copy content to clipboard
    $content = Get-Content -Path $githubHostsPath -Raw
    [System.Windows.Forms.Clipboard]::SetText($content)
    
    # Close form
    $form.Close()
    
    # Open hosts file
    Start-Process notepad -ArgumentList $hostsPath
})

$form.Controls.Add($button)

# Show form
$form.ShowDialog() | Out-Null